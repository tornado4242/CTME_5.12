package com.simplilearn.Calculator1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Calculator1Application {

	public static void main(String[] args) {
		SpringApplication.run(Calculator1Application.class, args);
	}

}
